
<div class="stat">
    <div class="stat-title">Pesquisas realizadas </div>
    <div class="stat-value"><?php echo e($todays); ?></div>
    <div class="stat-desc">no dia de hoje <?php echo e($hoje); ?></div>
</div>

<div class="stat">
    <div class="stat-title">Nota média da Clínica</div>
    <div class="stat-value"><?php echo e($avg = number_format($avg, 2,'.','')); ?></div>
    <div class="stat-desc">no dia de hoje <?php echo e($hoje); ?></div>
</div>

<?php /**PATH C:\wamp64\www\PesquisaApp\resources\views/admin/stats/ratings-hoje.blade.php ENDPATH**/ ?>