<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="hero h-screen bg-base-200">
        <div class="hero-content text-center">
            <div class="max-w-full">
                <form name="formSearch" id="formSearch" method="POST" action="<?php echo e(route('get-dados')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="max-w-full grid justify-items-center">
                        <img src="<?php echo e(URL::asset('image/LOGO_ULTRIMAGEM.png')); ?>" class="py-10" width="250px" height="250px"></img>
                        <h1 class="text-5xl font-bold">Seja bem-vindo!</h1>    
                        <p class="py-6 text-xl">Para iniciar insira abaixo o <b>código de pesquisa de satisfação</b> presente em seu protocolo.</p>
                        <input autofocus minlength="6" maxlength="6" type="number" required placeholder="Insira o código de pesquisa" id="id" name="id" class="input input-bordered input-primary w-full max-w-sm text-lg" />
                        <button class="btn mt-10 btn-primary btn-wide">Buscar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\PesquisaApp\resources\views/welcome.blade.php ENDPATH**/ ?>