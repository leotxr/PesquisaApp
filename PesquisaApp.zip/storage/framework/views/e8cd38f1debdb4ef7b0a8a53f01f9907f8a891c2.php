<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form name="formAgendamento" id="formAgendamento" method="POST" action="<?php echo e(route('sendDados')); ?>">
        <?php echo csrf_field(); ?>
        <div class="hero h-screen bg-base-200">
            <div class="hero-content text-center">
                <div class="max-w-full">
                    <?php $__currentLoopData = $requisicoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisicao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h1 class="text-3xl font-bold">Olá, <?php echo e($requisicao->PACIENTE); ?></h1>
                    <input class="text-3xl font-bold" id="data_req" name="data_req" value="<?php echo e($requisicao->DATA); ?>" style="display: none;"></input>
                    <input class="text-3xl font-bold" id="id" name="id" value="<?php echo e($requisicao->REQUISICAOID); ?>" style="display: none;"></input>
                    <input class="text-3xl font-bold" id="paciente_id" name="paciente_id" value="<?php echo e($requisicao->PACIENTEID); ?>" style="display: none;"></input>
                    <input class="text-3xl font-bold" id="paciente_name" name="paciente_name" value="<?php echo e($requisicao->PACIENTE); ?>" style="display: none;"></input>
                    <p class="py-4 text-3xl">para melhor atendê-lo(a), gostaríamos de saber se foi atendido(a):</p>

                    <div class="rating flex gap-3 justify-center py-5" id="rating" required>
                    <div class="form-check form-check-inline h-30 w-30 m-10">
                            <label class="text-lg font-bold">
                                <input type="radio" name="horario" value="3" id="checkbox" class="radio" style="opacity: 0; position: absolute;" />
                                <img src="<?php echo e(URL::asset('image/SMILE-05.png')); ?>" class="active:scale-125"></img>
                                Antes do horário
                            </label>
                        </div>
                        <div class="form-check form-check-inline h-30 w-30 m-10">
                        <label class="text-lg font-bold">
                                <input type="radio" name="horario" value="2" id="checkbox" class="radio" style="opacity: 0; position: absolute;" />
                                <img src="<?php echo e(URL::asset('image/SMILE-04.png')); ?>" class="active:scale-125"></img>
                                No horário marcado
                            </label>
                        </div>
                        <div class="form-check form-check-inline h-30 w-30 m-10">
                        <label class="text-lg font-bold">
                                <input type="radio" name="horario" value="1" class="radio" style="opacity: 0; position: absolute;" />
                                <img src="<?php echo e(URL::asset('image/SMILE-01.png')); ?>" class="active:scale-125"></img>
                                Depois do horário
                            </label>
                        </div>

                    </div>
                    <button type="submit" id="btn-show-agenda" href="" onclick="alterarDiv(this)" class="my-10 btn btn-primary btn-wide">Avançar</button>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<script>
    $(document).ready(function() {
        setTimeout(function() {
            window.location.href = "/";
        }, 60000);
    });
</script>
<?php /**PATH C:\wamp64\www\PesquisaApp\resources\views/agendamento.blade.php ENDPATH**/ ?>