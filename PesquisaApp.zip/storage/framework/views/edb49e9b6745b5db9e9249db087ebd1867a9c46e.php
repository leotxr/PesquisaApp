<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form name="formUltri" id="formUltri" method="POST" action="<?php echo e(route('sendDadosUltri')); ?>">
        <?php echo csrf_field(); ?>
        <div class="hero h-screen bg-base-200">
            <div class="hero-content text-center justify-center">
                <div class="max-w-full">
                    <?php $__currentLoopData = $rating_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="text" class="text-3xl font-bold" id="id" name="id" value="<?php echo e($req); ?>" style="display: none;"></input>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p class=" text-3xl">Como você avalia a <b>Ultrimagem?</b></p>
                    <div class="rating flex justify-center gap-5 font-bold text-xl py-10" id="rating" required>
                        <div class="form-check form-check-inline h-30 w-30">
                            <label class="radio-inline font-bold">
                                <input type="radio" name="rate_clinica" value="1" class="radio" style="opacity: 0; position: absolute;" />
                                <img src="<?php echo e(URL::asset('image/SMILE-01.png')); ?>" class="active:scale-125"></img>
                                Péssimo
                            </label>
                        </div>

                        <div class="form-check form-check-inline h-30 w-30">
                            <label class="radio-inline">
                                <input type="radio" name="rate_clinica" value="2" id="checkbox" class="radio" style="opacity: 0; position: absolute;" />
                                <img src="<?php echo e(URL::asset('image/SMILE-02.png')); ?>" class="active:scale-125"></img>
                                Ruim
                            </label>
                        </div>

                        <div class="form-check form-check-inline h-30 w-30">
                            <label class="radio-inline">
                                <input type="radio" name="rate_clinica" value="3" id="checkbox" class="radio" style="opacity: 0; position: absolute;" />
                                <img src="<?php echo e(URL::asset('image/SMILE-03.png')); ?>" class="active:scale-125"></img>
                                Normal
                            </label>
                        </div>

                        <div class="form-check form-check-inline h-30 w-30">
                            <label class="radio-inline">
                                <input type="radio" name="rate_clinica" value="4" id="checkbox" class="radio" style="opacity: 0; position: absolute;" />
                                <img src="<?php echo e(URL::asset('image/SMILE-04.png')); ?>" class="active:scale-125"></img>
                                Bom
                            </label>
                        </div>

                        <div class="form-check form-check-inline h-30 w-30">
                            <label class="radio-inline">
                                <input type="radio" name="rate_clinica" value="5" id="checkbox" class="radio" style="opacity: 0; position: absolute;" />
                                <img src="<?php echo e(URL::asset('image/SMILE-05.png')); ?>" class="active:scale-125"></img>
                                Ótimo
                            </label>
                        </div>
                    </div>
                    <button type="submit" id="btn-ultri" href="" class="my-10 btn btn-primary btn-wide ">Avançar</button>
                </div>
            </div>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<script>
    $(document).ready(function() {
        setTimeout(function() {
            window.location.href = "/";
        }, 30000);
    });
</script>
<?php /**PATH C:\wamp64\www\PesquisaApp\resources\views/rate-ultri.blade.php ENDPATH**/ ?>