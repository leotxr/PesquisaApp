<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form name="formUltri" id="formUltri" method="POST" action="<?php echo e(route('sendComent')); ?>">
        <?php echo csrf_field(); ?>
        <div class="hero h-screen bg-base-200">
            <div class="hero-content text-center justify-center">
                <div class="max-w-full">
                    <p class=" text-3xl py-10">Deseja adicionar um <b>comentário</b> ou <b>sugestão?</b></p>
                    <input type="text" class="text-3xl font-bold" id="id" name="id" value="<?php echo e($id); ?>" style="display: none;"></input>

                    <textarea type="text" name="comentario" oninput='if(this.scrollHeight > this.offsetHeight) this.rows += 1' placeholder="Comentários / Sugestões - (Opcional)" class="textarea textarea-primary w-full justify-center mb-10 text-xl" autofocus></textarea>
                    <button type="submit" id="btn-end" href="" class="my-10 btn btn-primary btn-wide ">Finalizar</button>
                </div>
            </div>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<script>
    $(document).ready(function() {
        setTimeout(function() {
            window.location.href = "/";
        }, 120000);


    });
</script>
<?php /**PATH C:\wamp64\www\PesquisaApp\resources\views/optional-coment.blade.php ENDPATH**/ ?>