
<div class="stat">
    <div class="stat-title">Pesquisas realizadas </div>
    <div class="stat-value"><?php echo e($year); ?></div>
    <div class="stat-desc">este ano</div>
</div>

<div class="stat">
    <div class="stat-title">Nota média da Clínica</div>
    <div class="stat-value"><?php echo e($avg = number_format($avg, 2,'.','')); ?></div>
    <div class="stat-desc">este ano</div>
</div>

<?php /**PATH C:\wamp64\www\PesquisaApp\resources\views/admin/stats/ratings-ano.blade.php ENDPATH**/ ?>