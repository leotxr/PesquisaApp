
<div id="stack" class="stack cursor-pointer m-2">
    <div class="stats bg-success text-success-content">

        <div class="stat">
            <div class="stat-title">Total de Notas positivas</div>
            <div class="stat-value"><?php echo e($positivas); ?></div>
        </div>

    </div>

    <div class="stats bg-warning text-warning-content my-5">

        <div class="stat">
            <div class="stat-title">Total de Notas neutras</div>
            <div class="stat-value"><?php echo e($neutras); ?></div>
        </div>
    </div>


    <div class="stats bg-error text-error-content my-5">

        <div class="stat">
            <div class="stat-title">Total de Notas negativas</div>
            <div class="stat-value"><?php echo e($negativas); ?></div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $("#stack").click(function() {
            $(this).toggleClass("stack");
        });
    });
</script>
<?php /**PATH C:\wamp64\www\PesquisaApp\resources\views/admin/stats/stats-clinica.blade.php ENDPATH**/ ?>