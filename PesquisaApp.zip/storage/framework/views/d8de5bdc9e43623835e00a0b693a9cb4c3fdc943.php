<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Relatório de Avaliação por Setor')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12" id="rel-usg">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b text-center border-gray-200">
                    <div class="flex w-full">
                        <div class="flex flex-col w-full lg:flex-row">
                            <div class="grid flex-grow h-32 card bg-white-200 rounded-box place-items-center">
                                <label>Data Inicial</label>
                                <input type="date" id="data_inicio" placeholder="Data Inicial" value="" class="input input-bordered input-primary w-full max-w-xs" />
                            </div>
                            <div class="divider lg:divider-horizontal">até</div>
                            <div class="grid flex-grow h-32 card bg-white-200 rounded-box place-items-center">
                                <label>Data Final</label>
                                <input type="date" id="data_final" placeholder="Data Final" value="" class="input input-bordered input-primary w-full max-w-xs" />
                            </div>
                        </div>
                    </div>
                    <div class="divider"></div>


                    <div class="p-2 flex">
                        <select id="setores" name="setores" class="select select-primary align-item-left max-w-xs">
                            <option value="0" default>Setores</option>
                            <option value="1">USG / Cardiologia</option>
                            <option value="2">Ressonância / Tomografia</option>
                            <option value="3">Radiologia</option>
                        </select>
                    </div>

                    <div class="p-2 flex">
                        <select id="ordem" name="ordem" class="select select-primary align-item-left max-w-xs">
                            <option value="data_req" default>Ordenar por:</option>
                            <option value="data_req">Data</option>
                            <option value="setor">Setor</option>
                            <option value="pac_name">Nome Paciente</option>
                            <option value="livro_name">Livro</option>
                        </select>
                    </div>
                    <a type="button" id="pick-date" class="my-2 btn btn-primary btn-wide ">Buscar</a>
                </div>

            </div>
        </div>
        <div id="show-result">

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<script>
    $("#pick-date").click(function() {
        const url = "<?php echo e(route('resultSetores')); ?>";
        dataInicio = $("#data_inicio").val();
        dataFinal = $("#data_final").val();
        ordem = $("#ordem").val();
        setores = $("#setores").val();
        $.ajax({
            url: url,
            data: {
                'data_inicio': dataInicio,
                'data_final': dataFinal,
                'ordem': ordem,
                'setores': setores
            },
            success: function(data) {
                $("#show-result").html(data);
            }
        });
    });
</script><?php /**PATH C:\wamp64\www\PesquisaApp\resources\views/admin/rel-setores.blade.php ENDPATH**/ ?>