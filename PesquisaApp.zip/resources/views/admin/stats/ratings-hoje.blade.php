
<div class="stat">
    <div class="stat-title">Pesquisas realizadas </div>
    <div class="stat-value">{{$todays}}</div>
    <div class="stat-desc">no dia de hoje {{$hoje}}</div>
</div>

<div class="stat">
    <div class="stat-title">Nota média da Clínica</div>
    <div class="stat-value">{{$avg = number_format($avg, 2,'.','')}}</div>
    <div class="stat-desc">no dia de hoje {{$hoje}}</div>
</div>

