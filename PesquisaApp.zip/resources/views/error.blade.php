<x-guest-layout>
    <div class="hero min-h-screen bg-base-200">
        <div class="hero-content text-center">
            <div class="max-w-md">
                <h1 class="text-5xl font-bold">Ocorreu um erro :(</h1>
                <p class="py-6">EXPIRACAO {{$datadif}}</p>
                <p class="py-6" >HOJE {{$hoje}}</p>
              


                <button class="btn btn-warning">Tentar Novamente</button>
            </div>
        </div>
    </div>
</x-guest-layout>
